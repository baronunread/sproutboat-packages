@echo off
node runtime %*
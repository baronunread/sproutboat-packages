import type {} from './porffor.d.ts';

// 20.3.1.1 Boolean (value)
// https://tc39.es/ecma262/#sec-boolean-constructor-boolean-value
export const Boolean = function (value: any): boolean|any {
  // 1. Let b be ToBoolean(value).
  const b: boolean = !!value;

  // 2. If NewTarget is undefined, return b.
  if (!new.target) return b;

  return b as BooleanObject;
};

// 20.3.3.2 Boolean.prototype.toString ()
// https://tc39.es/ecma262/#sec-boolean.prototype.tostring
export const __Boolean_prototype_toString = function (this: boolean) {
  // 1. Let b be ? ThisBooleanValue(this value).
  // 2. If b is true, return "true"; else return "false".
  // Boolean objects hold their [[BooleanData]] inline (and are always truthy)
  if (Porffor.IR.ptr(this) != 0) return 'true';
  return 'false';
};

// 20.3.3.3 Boolean.prototype.valueOf ()
// https://tc39.es/ecma262/#sec-boolean.prototype.valueof
export const __Boolean_prototype_valueOf = function (this: boolean) {
  // 1. Return ? ThisBooleanValue(this value).
  return Porffor.IR.ptr(this) != 0;
};

import type {} from './porffor.d.ts';

let __Porffor_json_bufLimit: i32 = 0;
// wide chars are buffered as uppercase \uXXXX escapes, widened at the end
let __Porffor_json_wide: boolean = false;

export const __Porffor_json_hexDigit = (n: i32, upper: boolean): i32 => n < 10 ? n + 48 : n + (upper ? 55 : 87);

export const __Porffor_bytestring_bufferStr = (buffer: i32, str: bytestring): i32 => {
  const len: i32 = str.length;
  if (buffer + 4 + len > __Porffor_json_bufLimit) return buffer + len;
  let strPtr: i32 = Porffor.IR.ptr(str);
  let ptr: i32 = buffer;
  let endPtr: i32 = ptr + len;

  while (ptr + 4 <= endPtr) {
    Porffor.IR.storeI32(ptr, 4, Porffor.IR.loadI32(strPtr, 4));
    ptr += 4;
    strPtr += 4;
  }

  while (ptr < endPtr) {
    Porffor.IR.storeU8(ptr++, 4, Porffor.IR.loadU8(strPtr++, 4));
  }

  return ptr;
};

export const __Porffor_bytestring_bufferChar = (buffer: i32, char: i32): i32 => {
  if (buffer + 5 > __Porffor_json_bufLimit) return buffer + 1;
  Porffor.IR.storeU8(buffer, 4, char);
  return buffer + 1;
};

export const __Porffor_bytestring_buffer2Char = (buffer: i32, char1: i32, char2: i32): i32 => {
  if (buffer + 6 > __Porffor_json_bufLimit) return buffer + 2;
  Porffor.IR.storeU8(buffer, 4, char1);
  Porffor.IR.storeU8(buffer + 1, 4, char2);
  return buffer + 2;
};

export const __Porffor_json_canSerialize = (value: any): boolean => {
  if (Porffor.fastOr(
    value === null,
    value === true,
    value === false,
    (Porffor.type(value) | 0b10000000) == Porffor.TYPES.bytestring,
    Porffor.type(value) == Porffor.TYPES.stringobject,
    Porffor.type(value) == Porffor.TYPES.number,
    Porffor.type(value) == Porffor.TYPES.numberobject,
    Porffor.type(value) == Porffor.TYPES.booleanobject,
    Porffor.type(value) == Porffor.TYPES.array,
    Porffor.type(value) > Porffor.TYPES.function
  )) return true;

  if (Porffor.type(value) == Porffor.TYPES.bigint) {
    throw new TypeError('Cannot serialize BigInts');
  }

  return false;
};

export const __Porffor_json_toJSON = (value: any, key: any): any => {
  if (Porffor.object.isObject(value)) {
    const toJSON: any = value.toJSON;
    if (Porffor.type(toJSON) == Porffor.TYPES.function) return toJSON.call(value, ecma262.ToString(key));
  }
  return value;
};

export const __Porffor_json_serialize = (_buffer: i32, value: any, depth: i32, space: bytestring|undefined, stack: any[]): i32 => {
  // somewhat modelled after 25.5.2.2 SerializeJSONProperty: https://tc39.es/ecma262/#sec-serializejsonproperty
  let buffer: i32 = _buffer;

  // boxed primitives -> their primitive
  if (Porffor.type(value) == Porffor.TYPES.numberobject) value = ecma262.ToNumber(value);
    else if (Porffor.type(value) == Porffor.TYPES.stringobject) value = ecma262.ToString(value);
    else if (Porffor.type(value) == Porffor.TYPES.booleanobject) value = Porffor.callThis(__Boolean_prototype_valueOf, value);

  if (__JSON_isRawJSON(value)) {
    let raw: any = value.rawJSON;
    if (Porffor.type(raw) == Porffor.TYPES.string) {
      __Porffor_json_wide = true;
      raw = __Porffor_json_escapeWide(raw);
    }
    return __Porffor_bytestring_bufferStr(buffer, raw);
  }
  if (value === null) return __Porffor_bytestring_bufferStr(buffer, 'null');
  if (value === true) return __Porffor_bytestring_bufferStr(buffer, 'true');
  if (value === false) return __Porffor_bytestring_bufferStr(buffer, 'false');

  if ((Porffor.type(value) | 0b10000000) == Porffor.TYPES.bytestring) {
    buffer = __Porffor_bytestring_bufferChar(buffer, 34); // start "

    const len: i32 = value.length;
    for (let i: i32 = 0; i < len; i++) {
      const c: i32 = value.charCodeAt(i);
      if (c < 0x20) {
        if (c == 0x08) {
          buffer = __Porffor_bytestring_buffer2Char(buffer, 92, 98); // \b
          continue;
        }

        if (c == 0x09) {
          buffer = __Porffor_bytestring_buffer2Char(buffer, 92, 116); // \t
          continue;
        }

        if (c == 0x0a) {
          buffer = __Porffor_bytestring_buffer2Char(buffer, 92, 110); // \n
          continue;
        }

        if (c == 0x0c) {
          buffer = __Porffor_bytestring_buffer2Char(buffer, 92, 102); // \f
          continue;
        }

        if (c == 0x0d) {
          buffer = __Porffor_bytestring_buffer2Char(buffer, 92, 114); // \r
          continue;
        }

        // \u00ff
        buffer = __Porffor_bytestring_buffer2Char(buffer, 92, 117); // \u
        buffer = __Porffor_bytestring_buffer2Char(buffer, 48, 48); // 00

        const h1: i32 = (c & 0xf0) / 0x10;
        const h2: i32 = c & 0x0f;
        buffer = __Porffor_bytestring_buffer2Char(buffer, h1 < 10 ? h1 + 48 : h1 + 87, h2 < 10 ? h2 + 48 : h2 + 87); // 0-9 or a-f
        continue;
      }

      if (c == 0x22) { // "
        buffer = __Porffor_bytestring_buffer2Char(buffer, 92, 34); // \"
        continue;
      }

      if (c == 0x5c) { // \
        buffer = __Porffor_bytestring_buffer2Char(buffer, 92, 92); // \\
        continue;
      }

      if (c > 0xff) {
        // lone surrogates stay escaped in lowercase hex
        const lone: boolean = c >= 0xd800 && c <= 0xdfff && !(c <= 0xdbff ? i + 1 < len && (value.charCodeAt(i + 1) & 0xfc00) == 0xdc00 : i > 0 && (value.charCodeAt(i - 1) & 0xfc00) == 0xd800);
        if (!lone) __Porffor_json_wide = true;
        buffer = __Porffor_bytestring_buffer2Char(buffer, 92, 117); // \u
        buffer = __Porffor_bytestring_buffer2Char(buffer, __Porffor_json_hexDigit(c >> 12, !lone), __Porffor_json_hexDigit((c >> 8) & 15, !lone));
        buffer = __Porffor_bytestring_buffer2Char(buffer, __Porffor_json_hexDigit((c >> 4) & 15, !lone), __Porffor_json_hexDigit(c & 15, !lone));
        continue;
      }

      buffer = __Porffor_bytestring_bufferChar(buffer, c);
    }

    return __Porffor_bytestring_bufferChar(buffer, 34); // final "
  }

  if (Porffor.type(value) == Porffor.TYPES.number) {
    if (Number.isFinite(value)) {
      return __Porffor_bytestring_bufferStr(buffer, Porffor.callThis(__Number_prototype_toString, value, 10));
    }

    return __Porffor_bytestring_bufferStr(buffer, 'null');
  }

  if (Porffor.type(value) > 0x06) {
    // ancestors are stack[0..depth), a cycle keeps recursing so checking at powers of two still finds it
    if ((depth & (depth - 1)) == 0) for (let i: i32 = 0; i < depth; i++) if (stack[i] === value) throw new TypeError('Converting circular structure to JSON');
    stack[depth] = value;
  }

  // proxied arrays read their elements through the proxy
  if (Porffor.comptime.flag`hasFunc.Proxy`) {
    if (Porffor.fastAnd(Porffor.type(value) == Porffor.TYPES.proxy, __Array_isArray(value))) {
      const elements: any[] = [];
      const length: i32 = __Porffor_array_lengthOf(value);
      for (let i: i32 = 0; i < length; i++) Porffor.array.fastPush(elements, value[i]);
      value = elements;
    }
  }

  if (Porffor.type(value) == Porffor.TYPES.array) {
    buffer = __Porffor_bytestring_bufferChar(buffer, 91); // [

    const hasSpace: boolean = space !== undefined;
    depth += 1;

    let i: i32 = 0;
    for (const item of (value as any[])) {
      const x: any = __Porffor_json_toJSON(item, i++);
      if (hasSpace) {
        buffer = __Porffor_bytestring_bufferChar(buffer, 10); // \n
        for (let i: i32 = 0; i < depth; i++) buffer = __Porffor_bytestring_bufferStr(buffer, space as bytestring);
      }

      if (__Porffor_json_canSerialize(x)) {
        buffer = __Porffor_json_serialize(buffer, x, depth, space, stack);
      } else {
        // non-serializable value, write null
        buffer = __Porffor_bytestring_bufferStr(buffer, 'null');
      }

      buffer = __Porffor_bytestring_bufferChar(buffer, 44); // ,
    }

    depth -= 1;

    // swap trailing , with ] (or \n or append if empty)
    if ((buffer - _buffer) > 1) {
      if (hasSpace) {
        if (buffer + 4 <= __Porffor_json_bufLimit) Porffor.IR.storeU8(buffer, 3, 10); // \n
        for (let i: i32 = 0; i < depth; i++) buffer = __Porffor_bytestring_bufferStr(buffer, space as bytestring);
        return __Porffor_bytestring_bufferChar(buffer, 93); // ]
      }

      if (buffer + 4 <= __Porffor_json_bufLimit) Porffor.IR.storeU8(buffer, 3, 93); // ]
      return buffer;
    }

    return __Porffor_bytestring_bufferChar(buffer, 93); // ]
  }

  if (Porffor.type(value) > 0x06) {
    // non-function object
    buffer = __Porffor_bytestring_bufferChar(buffer, 123); // {

    const hasSpace: boolean = space !== undefined;
    depth += 1;

    // own keys only, for..in also walks inherited ones
    const inherited: i32 = __Porffor_object_hasInheritedEnumerable(value);
    for (const key: any in value) {
      // skip symbol keys
      if (Porffor.type(key) == Porffor.TYPES.symbol) continue;
      if (inherited && !__Object_hasOwn(value, key)) continue;

      const val: any = __Porffor_json_toJSON(value[key], key);
      if (!__Porffor_json_canSerialize(val)) {
        // skip non-serializable value
        continue;
      }

      if (hasSpace) {
        buffer = __Porffor_bytestring_bufferChar(buffer, 10); // \n
        for (let i: i32 = 0; i < depth; i++) buffer = __Porffor_bytestring_bufferStr(buffer, space as bytestring);
      }

      buffer = __Porffor_json_serialize(buffer, key, depth, space, stack);
      buffer = __Porffor_bytestring_bufferChar(buffer, 58); // :
      if (hasSpace) buffer = __Porffor_bytestring_bufferChar(buffer, 32); // space

      buffer = __Porffor_json_serialize(buffer, val, depth, space, stack);
      buffer = __Porffor_bytestring_bufferChar(buffer, 44); // ,
    }

    depth -= 1;

    // swap trailing , with } (or \n or append if empty)
    if ((buffer - _buffer) > 1) {
      if (hasSpace) {
        if (buffer + 4 <= __Porffor_json_bufLimit) Porffor.IR.storeU8(buffer, 3, 10); // \n
        for (let i: i32 = 0; i < depth; i++) buffer = __Porffor_bytestring_bufferStr(buffer, space as bytestring);
        return __Porffor_bytestring_bufferChar(buffer, 125); // }
      }

      if (buffer + 4 <= __Porffor_json_bufLimit) Porffor.IR.storeU8(buffer, 3, 125); // }
      return buffer;
    }

    return __Porffor_bytestring_bufferChar(buffer, 125); // }
  }

  if (Porffor.type(value) == 0x04) {
    // bigint
    throw new TypeError('Cannot serialize BigInts');
  }

  return -1;
};

// replacer (and toJSON) applied up front into a plain tree, so the serializer can run twice
export const __Porffor_json_prepare = (holder: any, key: any, value: any, replacer: any, keys: any, stack: any[]): any => {
  value = __Porffor_json_toJSON(value, key);
  if (Porffor.type(replacer) == Porffor.TYPES.function) value = replacer.call(holder, key, value);

  if (Porffor.fastOr(!Porffor.object.isObject(value), Porffor.type(value) == Porffor.TYPES.function, __Porffor_json_canSerialize(value) == false)) return value;
  if (Porffor.fastOr(Porffor.type(value) == Porffor.TYPES.numberobject, Porffor.type(value) == Porffor.TYPES.stringobject, Porffor.type(value) == Porffor.TYPES.booleanobject, __JSON_isRawJSON(value))) return value;
  if (stack.includes(value)) throw new TypeError('Converting circular structure to JSON');
  Porffor.array.fastPush(stack, value);

  let out: any;
  if (Array.isArray(value)) {
    out = Porffor.array.new(0);
    const len: i32 = value.length;
    for (let i: i32 = 0; i < len; i++) {
      const v: any = __Porffor_json_prepare(value, Porffor.callThis(__Number_prototype_toString, i), value[i], replacer, keys, stack);
      out[i] = __Porffor_json_canSerialize(v) ? v : null;
    }
  } else {
    out = {};
    const objKeys: any[] = keys ?? Object.keys(value);
    for (let i: i32 = 0; i < objKeys.length; i++) {
      const k: any = objKeys[i];
      const v: any = __Porffor_json_prepare(value, k, value[k], replacer, keys, stack);
      if (__Porffor_json_canSerialize(v)) out[k] = v;
    }
  }

  stack.pop();
  return out;
};

export const __JSON_rawJSON = (text: any): object => {
  const jsonString: any = ecma262.ToString(text);
  const len: i32 = jsonString.length;
  if (len == 0) throw new SyntaxError('Invalid raw JSON text');

  // no surrounding whitespace, objects or arrays
  const first: i32 = jsonString.charCodeAt(0);
  const last: i32 = jsonString.charCodeAt(len - 1);
  if (Porffor.fastOr(first == 9, first == 10, first == 13, first == 32, first == 91, first == 123,
    last == 9, last == 10, last == 13, last == 32)) throw new SyntaxError('Invalid raw JSON text');
  __JSON_parse(jsonString, undefined);

  const out: object = __Object_create(null);
  __Porffor_object_fastAdd(out, 'rawJSON', jsonString, 0b0100);

  // inextensible + [[IsRawJSON]]
  Porffor.IR.storeU8(out, 4, Porffor.IR.loadU8(out, 4) | 0b0101);
  return out;
};

export const __JSON_isRawJSON = (O: any): boolean => {
  if (Porffor.fastOr(Porffor.type(O) != Porffor.TYPES.object, O === null)) return false;
  return (Porffor.IR.loadU8(O, 4) & 0b0100) != 0;
};

export const __JSON_stringify = (value: any, replacer: any, space: any) => {
  if (Porffor.type(replacer) == Porffor.TYPES.function) {
    const holder: object = {};
    holder[''] = value;
    value = __Porffor_json_prepare(holder, '', value, replacer, undefined, Porffor.array.new(0));
  } else if (Array.isArray(replacer)) {
    const keys: any[] = Porffor.array.new(0);
    for (let i: i32 = 0; i < replacer.length; i++) {
      const x: any = replacer[i];
      let k: any = undefined;
      if (Porffor.fastOr((Porffor.type(x) | 0b10000000) == Porffor.TYPES.bytestring, Porffor.type(x) == Porffor.TYPES.number,
        Porffor.type(x) == Porffor.TYPES.stringobject, Porffor.type(x) == Porffor.TYPES.numberobject)) k = ecma262.ToString(x);
      if (k !== undefined && !keys.includes(k)) Porffor.array.fastPush(keys, k);
    }
    const holder: object = {};
    holder[''] = value;
    value = __Porffor_json_prepare(holder, '', value, undefined, keys, Porffor.array.new(0));
  } else {
    value = __Porffor_json_toJSON(value, '');
  }

  if (space !== undefined) {
    if (Porffor.fastOr(
      Porffor.type(space) == Porffor.TYPES.number,
      Porffor.type(space) == Porffor.TYPES.numberobject
    )) {
      space = Math.min(Math.trunc(space), 10);

      if (space < 1) {
        space = undefined;
      } else {
        const spaceStr: bytestring = Porffor.malloc(6 + space);
        Porffor.IR.storeI32(spaceStr, 0, 0);
        for (let i: i32 = 0; i < space; i++) Porffor.bytestring.appendChar(spaceStr, 32);

        space = spaceStr;
      }
    } else if (Porffor.fastOr(
      (Porffor.type(space) | 0b10000000) == Porffor.TYPES.bytestring,
      Porffor.type(space) == Porffor.TYPES.stringobject
    )) {
      // if empty, make it undefined
      const len: i32 = space.length;
      if (len == 0) {
        space = undefined;
      } else if (len > 10) {
        space = space.slice(0, 10);
      }
    } else {
      // not a number or string, make it undefined
      space = undefined;
    }
  }

  // a getter or toJSON can stringify mid-serialize
  const outerWide: boolean = __Porffor_json_wide;
  const outerLimit: i32 = __Porffor_json_bufLimit;
  __Porffor_json_wide = false;
  let cap: i32 = 4096;
  let buffer: bytestring = Porffor.malloc(6 + cap);
  __Porffor_json_bufLimit = (buffer as i32) + 4 + cap;
  let out: i32 = __Porffor_json_serialize(buffer, value, 0, space, Porffor.array.new(0));
  const needed: i32 = out - (buffer as i32);
  if (needed > cap) {
    cap = needed;
    buffer = Porffor.malloc(6 + cap);
    __Porffor_json_bufLimit = (buffer as i32) + 4 + cap;
    out = __Porffor_json_serialize(buffer, value, 0, space, Porffor.array.new(0));
  }

  const hasWide: boolean = __Porffor_json_wide;
  __Porffor_json_wide = outerWide;
  __Porffor_json_bufLimit = outerLimit;
  if (out == -1) return undefined;

  const len: i32 = out - (buffer as i32);
  buffer.length = len;
  if (!hasWide) return buffer;

  // widen uppercase \uXXXX escapes past latin-1
  const wide: string = Porffor.malloc(4 + len * 2);
  const base: i32 = buffer as i32;
  let n: i32 = 0;
  for (let i: i32 = 0; i < len; i++) {
    let c: i32 = Porffor.IR.loadU8(base + i, 4);
    if (c == 92) {
      let code: i32 = -1;
      if (Porffor.fastAnd(i + 5 < len, Porffor.IR.loadU8(base + i + 1, 4) == 117)) {
        code = 0;
        for (let j: i32 = 2; j < 6; j++) {
          const d: i32 = Porffor.IR.loadU8(base + i + j, 4);
          if (d >= 48 && d <= 57) code = code * 16 + d - 48;
            else if (d >= 65 && d <= 70) code = code * 16 + d - 55;
            else code = -1;
          if (code < 0) break;
        }
      }
      if (code > 0xff) {
        c = code;
        i += 5;
      } else {
        // other escapes are copied whole so an escaped backslash can't start one
        Porffor.IR.storeU16((wide as i32) + n * 2, 4, 92);
        n++;
        i++;
        c = Porffor.IR.loadU8(base + i, 4);
      }
    }
    Porffor.IR.storeU16((wide as i32) + n * 2, 4, c);
    n++;
  }
  wide.length = n;
  return wide;
};


export const __Porffor_json_skipWhitespace = (text: bytestring, pos: i32, len: i32): i32 => {
  while (pos < len) {
    const c: i32 = text.charCodeAt(pos);
    if (c > 32) break; // fast path

    if (c == 32 || c == 9 || c == 10 || c == 13) pos++;
      else break;
  }

  return pos;
};

export const __Porffor_json_skipDigits = (text: bytestring, pos: i32, len: i32): i32 => {
  while (pos < len) {
    const c: i32 = text.charCodeAt(pos);
    if (c < 48 || c > 57) break;
    pos++;
  }

  return pos;
};

// parse records for reviver source text: [ value, source or child records ]
export const __Porffor_json_parseRecord = (text: bytestring, posPtr: i32, len: i32): any[] => {
  const start: i32 = __Porffor_json_skipWhitespace(text, Porffor.IR.loadI32(posPtr, 0), len);
  Porffor.IR.storeI32(posPtr, 0, start);

  const rec: any[] = Porffor.array.new(2);
  rec.length = 2;
  rec[0] = __Porffor_json_parseValue(text, posPtr, len, rec);
  if (!Porffor.object.isObject(rec[0])) rec[1] = Porffor.callThis(__ByteString_prototype_slice, text, start, Porffor.IR.loadI32(posPtr, 0));
  return rec;
};

export const __Porffor_json_parseValue = (text: bytestring, posPtr: i32, len: i32, rec: any): any => {
  let pos: i32 = __Porffor_json_skipWhitespace(text, Porffor.IR.loadI32(posPtr, 0), len);
  if (pos >= len) throw new SyntaxError('Unexpected end of JSON input');

  const c: i32 = text.charCodeAt(pos);
  if (c == 110) { // 'n' - null
    if (pos + 4 <= len &&
        text.charCodeAt(pos + 1) == 117 && // 'u'
        text.charCodeAt(pos + 2) == 108 && // 'l'
        text.charCodeAt(pos + 3) == 108) { // 'l'
      pos += 4;
      Porffor.IR.storeI32(posPtr, 0, pos);
      return null;
    }
    throw new SyntaxError('Unexpected token');
  }

  if (c == 116) { // 't' - true
    if (pos + 4 <= len &&
        text.charCodeAt(pos + 1) == 114 && // 'r'
        text.charCodeAt(pos + 2) == 117 && // 'u'
        text.charCodeAt(pos + 3) == 101) { // 'e'
      pos += 4;
      Porffor.IR.storeI32(posPtr, 0, pos);
      return true;
    }
    throw new SyntaxError('Unexpected token');
  }

  if (c == 102) { // 'f' - false
    if (pos + 5 <= len &&
        text.charCodeAt(pos + 1) == 97 && // 'a'
        text.charCodeAt(pos + 2) == 108 && // 'l'
        text.charCodeAt(pos + 3) == 115 && // 's'
        text.charCodeAt(pos + 4) == 101) { // 'e'
      pos += 5;
      Porffor.IR.storeI32(posPtr, 0, pos);
      return false;
    }
    throw new SyntaxError('Unexpected token');
  }

  if (c == 34) { // '"' - string
    pos++;
    const start: i32 = pos;

    let strEnd: i32 = pos;
    let hasEscape: boolean = false;
    while (strEnd < len) {
      const ch: i32 = text.charCodeAt(strEnd);
      if (ch == 34) break;
      if (ch == 92) {
        hasEscape = true;
        strEnd++;
      }
      strEnd++;
    }
    if (strEnd >= len) throw new SyntaxError('Unterminated string');

    const out: bytestring = Porffor.malloc(6 + (strEnd - pos));
    Porffor.IR.storeI32(out, 0, 0);

    if (!hasEscape) {
      while (pos < strEnd) {
        const ch: i32 = text.charCodeAt(pos);
        if (ch >= 0x00 && ch <= 0x1f) throw new SyntaxError('Unescaped control character');
        Porffor.bytestring.appendChar(out, ch);
        pos++;
      }
      pos++;
      Porffor.IR.storeI32(posPtr, 0, pos);
      return out;
    }

    while (pos < len) {
      const ch: i32 = text.charCodeAt(pos);
      if (ch == 34) { // closing "
        pos++;
        Porffor.IR.storeI32(posPtr, 0, pos);
        return out;
      }
      if (ch == 92) { // backslash
        pos++;
        if (pos >= len) throw new SyntaxError('Unterminated string');

        const esc: i32 = text.charCodeAt(pos++);
        if (esc == 34) Porffor.bytestring.appendChar(out, 34); // \"
          else if (esc == 92) Porffor.bytestring.appendChar(out, 92); // \\
          else if (esc == 47) Porffor.bytestring.appendChar(out, 47); // \/
          else if (esc == 98) Porffor.bytestring.appendChar(out, 8); // \b
          else if (esc == 102) Porffor.bytestring.appendChar(out, 12); // \f
          else if (esc == 110) Porffor.bytestring.appendChar(out, 10); // \n
          else if (esc == 114) Porffor.bytestring.appendChar(out, 13); // \r
          else if (esc == 116) Porffor.bytestring.appendChar(out, 9); // \t
          else if (esc == 117) { // \u
            const unicode: i32 = __Porffor_json_hex4(text, pos, len);
            pos += 4;
            if (unicode > 0xff) return __Porffor_json_parseWideString(text, start, posPtr, len);
            Porffor.bytestring.appendChar(out, unicode);
          } else throw new SyntaxError('Invalid escape sequence');
      } else {
        if (ch >= 0x00 && ch <= 0x1f) throw new SyntaxError('Unescaped control character');
        Porffor.bytestring.appendChar(out, ch);
        pos++;
      }
    }
    throw new SyntaxError('Unterminated string');
  }

  if (c == 91) { // '[' - array
    pos++;
    const arr: any[] = Porffor.array.new(4);
    if (rec !== undefined) rec[1] = Porffor.array.new(4);
    pos = __Porffor_json_skipWhitespace(text, pos, len);

    if (pos < len && text.charCodeAt(pos) == 93) { // empty array
      pos++;
      Porffor.IR.storeI32(posPtr, 0, pos);
      return arr;
    }

    while (true) {
      Porffor.IR.storeI32(posPtr, 0, pos);
      if (rec === undefined) {
        Porffor.array.fastPush(arr, __Porffor_json_parseValue(text, posPtr, len, undefined));
      } else {
        const child: any[] = __Porffor_json_parseRecord(text, posPtr, len);
        Porffor.array.fastPush(rec[1], child);
        Porffor.array.fastPush(arr, child[0]);
      }
      pos = __Porffor_json_skipWhitespace(text, Porffor.IR.loadI32(posPtr, 0), len);
      if (pos >= len) throw new SyntaxError('Unterminated array');

      const next: i32 = text.charCodeAt(pos);
      if (next == 93) { // ]
        pos++;
        Porffor.IR.storeI32(posPtr, 0, pos);
        break;
      }
      if (next == 44) { // ,
        pos++;
        continue;
      }
      throw new SyntaxError('Expected , or ]');
    }
    return arr;
  }

  if (c == 123) { // '{' - object
    pos++;
    const obj: any = {};
    if (rec !== undefined) rec[1] = __Object_create(null);
    pos = __Porffor_json_skipWhitespace(text, pos, len);

    if (pos < len && text.charCodeAt(pos) == 125) { // empty object
      pos++;
      Porffor.IR.storeI32(posPtr, 0, pos);
      return obj;
    }

    while (true) {
      pos = __Porffor_json_skipWhitespace(text, pos, len);
      if (pos >= len || text.charCodeAt(pos) != 34) throw new SyntaxError('Expected string key');

      Porffor.IR.storeI32(posPtr, 0, pos);
      const key: any = __Porffor_json_parseValue(text, posPtr, len, undefined);
      pos = __Porffor_json_skipWhitespace(text, Porffor.IR.loadI32(posPtr, 0), len);
      if (pos >= len || text.charCodeAt(pos) != 58) throw new SyntaxError('Expected :');
      pos++;

      Porffor.IR.storeI32(posPtr, 0, pos);
      if (rec === undefined) {
        __Porffor_object_define(obj, key, __Porffor_json_parseValue(text, posPtr, len, undefined), 0b1110);
      } else {
        const child: any[] = __Porffor_json_parseRecord(text, posPtr, len);
        __Porffor_object_define(rec[1], key, child, 0b1110);
        __Porffor_object_define(obj, key, child[0], 0b1110);
      }

      pos = __Porffor_json_skipWhitespace(text, Porffor.IR.loadI32(posPtr, 0), len);
      if (pos >= len) throw new SyntaxError('Unterminated object');

      const next: i32 = text.charCodeAt(pos);
      if (next == 125) { // }
        pos++;
        Porffor.IR.storeI32(posPtr, 0, pos);
        break;
      }
      if (next == 44) { // ,
        pos++;
        continue;
      }
      throw new SyntaxError('Expected , or }');
    }
    return obj;
  }

  // number
  if ((c >= 48 && c <= 57) || c == 45) { // 0-9 or -
    const start: i32 = pos;
    if (c == 45) pos++; // skip -

    // int part is 0 or starts with 1-9
    const intStart: i32 = pos;
    pos = __Porffor_json_skipDigits(text, pos, len);
    if (pos == intStart || (text.charCodeAt(intStart) == 48 && pos > intStart + 1)) throw new SyntaxError('Invalid number');

    if (pos < len && text.charCodeAt(pos) == 46) { // .
      const fracStart: i32 = ++pos;
      pos = __Porffor_json_skipDigits(text, pos, len);
      if (pos == fracStart) throw new SyntaxError('Invalid number');
    }

    if (pos < len && (text.charCodeAt(pos) | 32) == 101) { // e E
      pos++;
      if (pos < len && (text.charCodeAt(pos) == 43 || text.charCodeAt(pos) == 45)) pos++; // + -
      const expStart: i32 = pos;
      pos = __Porffor_json_skipDigits(text, pos, len);
      if (pos == expStart) throw new SyntaxError('Invalid number');
    }

    Porffor.IR.storeI32(posPtr, 0, pos);
    return ecma262.StringToNumber(Porffor.callThis(__ByteString_prototype_slice, text, start, pos));
  }

  throw new SyntaxError('Unexpected token');
};

export const __Porffor_json_internalize = (holder: any, name: any, reviver: any, rec: any): any => {
  const val: any = holder[name];
  const context: object = {};

  // records only describe values the reviver has not replaced
  let recs: any = undefined;
  if (rec != null) if (__Object_is(rec[0], val)) recs = rec[1];
  if (Porffor.object.isObject(val)) {
    const isArray: boolean = Array.isArray(val);
    const keys: any = isArray ? undefined : __Object_keys(val);
    const len: number = isArray ? __Porffor_array_lengthOf(val) : keys.length;
    for (let i: number = 0; i < len; i++) {
      const k: any = isArray ? ecma262.ToString(i) : keys[i];
      const v: any = __Porffor_json_internalize(val, k, reviver, recs === undefined ? undefined : recs[k]);
      if (v === undefined) __Reflect_deleteProperty(val, k);
        else __Reflect_defineProperty(val, k, { value: v, writable: true, enumerable: true, configurable: true });
    }
  } else if (recs !== undefined) __Porffor_object_fastAdd(context, 'source', recs, 0b1110);

  return reviver.call(holder, name, val, context);
};

// the 4 hex digits of a \u escape at pos
export const __Porffor_json_hex4 = (text: bytestring, pos: i32, len: i32): i32 => {
  if (pos + 4 >= len) throw new SyntaxError('Invalid unicode escape');
  let out: i32 = 0;
  for (let i: i32 = 0; i < 4; i++) {
    const hex: i32 = text.charCodeAt(pos + i);
    out <<= 4;
    if (hex >= 48 && hex <= 57) out |= hex - 48; // 0-9
      else if (hex >= 65 && hex <= 70) out |= hex - 55; // A-F
      else if (hex >= 97 && hex <= 102) out |= hex - 87; // a-f
      else throw new SyntaxError('Invalid unicode escape');
  }
  return out;
};

// strings with \u escapes past latin-1, from after the opening quote
export const __Porffor_json_parseWideString = (text: bytestring, start: i32, posPtr: i32, len: i32): string => {
  const out: string = Porffor.malloc(6 + (len - start) * 2);
  let n: i32 = 0, pos: i32 = start;
  while (pos < len) {
    let ch: i32 = text.charCodeAt(pos++);
    if (ch == 34) {
      out.length = n;
      Porffor.IR.storeI32(posPtr, 0, pos);
      return out;
    }
    if (ch < 0x20) throw new SyntaxError('Unescaped control character');
    if (ch == 92) {
      if (pos >= len) throw new SyntaxError('Unterminated string');
      const esc: i32 = text.charCodeAt(pos++);
      if (esc == 98) ch = 8;
        else if (esc == 102) ch = 12;
        else if (esc == 110) ch = 10;
        else if (esc == 114) ch = 13;
        else if (esc == 116) ch = 9;
        else if (esc == 117) {
          ch = __Porffor_json_hex4(text, pos, len);
          pos += 4;
        } else if (Porffor.fastOr(esc == 34, esc == 92, esc == 47)) ch = esc;
        else throw new SyntaxError('Invalid escape sequence');
    }
    Porffor.IR.storeU16((out as i32) + n * 2, 4, ch);
    n++;
  }
  throw new SyntaxError('Unterminated string');
};

// wide chars are only valid inside strings, so escaped they parse as a bytestring
export const __Porffor_json_escapeWide = (str: string): bytestring => {
  const len: i32 = str.length;
  let wide: i32 = 0;
  for (let i: i32 = 0; i < len; i++) if (str.charCodeAt(i) > 0xff) wide++;

  const out: bytestring = Porffor.malloc(6 + len + wide * 5);
  Porffor.IR.storeI32(out, 0, 0);
  let escaped: boolean = false;
  for (let i: i32 = 0; i < len; i++) {
    const c: i32 = str.charCodeAt(i);
    if (c > 0xff) {
      if (escaped) throw new SyntaxError('Invalid escape sequence');
      Porffor.bytestring.append2Char(out, 92, 117);
      Porffor.bytestring.append2Char(out, __Porffor_json_hexDigit(c >> 12, true), __Porffor_json_hexDigit((c >> 8) & 15, true));
      Porffor.bytestring.append2Char(out, __Porffor_json_hexDigit((c >> 4) & 15, true), __Porffor_json_hexDigit(c & 15, true));
    } else Porffor.bytestring.appendChar(out, c);
    escaped = c == 92 && !escaped;
  }
  return out;
};

export const __JSON_parse = (_: any, reviver: any) => {
  const raw: any = ecma262.ToString(_);
  const text: bytestring = Porffor.type(raw) == Porffor.TYPES.string ? __Porffor_json_escapeWide(raw) : raw;
  const posPtr: i32 = Porffor.malloc(4);
  Porffor.IR.storeI32(posPtr, 0, 0);

  const len: i32 = text.length;
  if (Porffor.comptime.flag`hasFunc.__Porffor_json_reviverUsed`) {
    if (Porffor.type(reviver) == Porffor.TYPES.function) {
      const rec: any = __Porffor_json_parseRecord(text, posPtr, len);
      if (__Porffor_json_skipWhitespace(text, Porffor.IR.loadI32(posPtr, 0), len) < len) throw new SyntaxError('Unexpected token after JSON');

      const root: object = {};
      __Porffor_object_fastAdd(root, '', rec[0], 0b1110);
      return __Porffor_json_internalize(root, '', reviver, rec);
    }
  }

  const value: any = __Porffor_json_parseValue(text, posPtr, len, undefined);
  if (__Porffor_json_skipWhitespace(text, Porffor.IR.loadI32(posPtr, 0), len) < len) throw new SyntaxError('Unexpected token after JSON');
  return value;
};

export const __Porffor_json_reviverUsed = (): void => {};
